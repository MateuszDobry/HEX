﻿#include <iostream>
#include <string>
#include <vector>

#include "isBoardCorrect.h"
#include "isBoardPossible.h"
#include "isGameOver.h"
#include "ktorePytanie.h"
#include "pomocniczeFunkcje.h"
#include "CanWinIn1MoveWithNaiveOpponent.h"
#include "CanWinIn2MoveWithNaiveOpponent.h"

using namespace std;

int main()
{
	int counter = 0;
	char c = ' ';
	while (c = (char)getchar() != EOF) {
		
		int red, blue;
		red = blue = 0;
		int size = 0;

		while (c != '-') {
			c = (char)getchar();
			size++;
		}
		//counter++;
		size /= 3;
		size++;

		while (getchar() != '\n');  // ZACZYNA WCZYTYWAC OD 2 ' - '
		
		char** board = new char* [size];
		for (int i = 0; i < size; i++) {
			board[i] = new char[size];
		}
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				board[i][j] = '0';
			}
		}
		for (int i = 0; i < 2 * size - 1; i++) {
			//counter++;
			c = '0';
			int j = 0;
			while (c != '\n') {
				
				c = (char)getchar();

				if (c == '<') {
					c = (char)getchar();
					if (c == ' ') {
						c = (char)getchar();
						if (i < size) {
							board[j][i - j] = c;
						}
						else {
							board[i - size + 1 + j][size - 1 - j] = c;
						}

						if (c == 'r') {
							red++;
						}
						if (c == 'b') {
							blue++;
						}
					}
					j++;
				}
			}
		}
		transpose(board, size);
		while (getchar() != '\n'); /// TUTAJ KONCZY WCZYTYWAC PLANSZE
		//counter++;
		string pytanie = "";
	pkt:

		while (pytanie[0] != '\n') {
			getline(cin, pytanie);
			//counter++;
			if (pytanie.empty()) {
				pytanie.push_back('\n');
			}
			if (pytanie[0] == '\n') {
				goto pkt;
			}
			int nrPytania = ktorePytanie(pytanie);
			if (nrPytania == 1) {
				cout << size << endl;
			}
			else if (nrPytania == 2) {
				cout << red + blue << endl;
			}
			else if (nrPytania == 3) {
				if (IS_BOARD_CORRECT(red, blue)) {
					cout << "YES" << endl;
				}
				else
					cout << "NO" << endl;
			}
			else if (nrPytania == 4) {
				if (IS_BOARD_CORRECT(red, blue)) {


					if (IS_GAME_OVER(board, 'r', size)) {
						cout << "YES RED" << endl;
					}
					else if (IS_GAME_OVER(board, 'b', size)) {
						cout << "YES BLUE" << endl;
					}
					else {
						cout << "NO" << endl;
					}
				}
				else {
					cout << "NO" << endl;
				}

			}
			else if (nrPytania == 5) {
				if (IS_BOARD_POSSIBLE(board, size, red, blue)) {
					cout << "YES" << endl;
				}
				else {
					cout << "NO" << endl;
				}
			}
			else if (nrPytania == 6) {
			/*	if (CAN_WIN_IN_1_MOVE_WITH_NAIVE_OPPONENT(board,size, red, blue,'r')) {
					cout << "YES";
				}
				else {
					cout << "NO";
				}*/
				
				char kolor = 'r';
				int wolne_miejsca = size * size - (red + blue);
				int wymagane_wolne_miejsca;
				if ((kolor == 'r') == (red == blue)) {
					wymagane_wolne_miejsca = 1;
				}
				else {
					wymagane_wolne_miejsca = 2;
				}

				if (wolne_miejsca == 0
					|| !IS_BOARD_POSSIBLE(board, size, red, blue)
					|| !IS_BOARD_CORRECT(red, blue)
					|| IS_GAME_OVER(board, 'r', size)
					|| IS_GAME_OVER(board, 'b', size)
					|| wolne_miejsca <= wymagane_wolne_miejsca) {
					std::cout << "NO";
				}
				else {
					char** kopia = kopiaCalejTab(board, size);
					bool znalezionoRozwiazanie = false;
					for (int i = 0; i < size && !znalezionoRozwiazanie; i++) {
						for (int j = 0; j < size && !znalezionoRozwiazanie; j++) {
							if (kopia[i][j] == ' ') {
								kopia[i][j] = kolor;
								if (IS_GAME_OVER(kopia, kolor, size)) {
									std::cout << "YES";
									znalezionoRozwiazanie = true;
								}
								else {
									kopia[i][j] = ' ';
								}
							}
						}
					}
					if (!znalezionoRozwiazanie) {
						std::cout << "NO";
					}
					usunTablice(kopia, size);
				}

			}
			else if (nrPytania == 7) {
				/*if (CAN_WIN_IN_1_MOVE_WITH_NAIVE_OPPONENT(board, size, red, blue, 'b')) {
					cout << "YES";
				}
				else {
					cout << "NO";
				}*/
				char kolor = 'b';
				int wolne_miejsca = size * size - (red + blue);
				int wymagane_wolne_miejsca;
				if ((kolor == 'r') == (red == blue)) {
					wymagane_wolne_miejsca = 1;
				}
				else {
					wymagane_wolne_miejsca = 2;
				}

				if (wolne_miejsca == 0
					|| !IS_BOARD_POSSIBLE(board, size, red, blue)
					|| !IS_BOARD_CORRECT(red, blue)
					|| IS_GAME_OVER(board, 'r', size)
					|| IS_GAME_OVER(board, 'b', size)
					|| wolne_miejsca <= wymagane_wolne_miejsca) {
					std::cout << "NO";
				}
				else {
					char** kopia = kopiaCalejTab(board, size);
					bool znalezionoRozwiazanie = false;
					for (int i = 0; i < size && !znalezionoRozwiazanie; i++) {
						for (int j = 0; j < size && !znalezionoRozwiazanie; j++) {
							if (kopia[i][j] == ' ') {
								kopia[i][j] = kolor;
								if (IS_GAME_OVER(kopia, kolor, size)) {
									std::cout << "YES";
									znalezionoRozwiazanie = true;
								}
								else {
									kopia[i][j] = ' ';
								}
							}
						}
					}
					if (!znalezionoRozwiazanie) {
						std::cout << "NO";
					}
					usunTablice(kopia, size);
				}

			}
			else if (nrPytania == 8) {
				if (CAN_WIN_IN_2_MOVES_WITH_NAIVE_OPPONENT(board, size, red, blue, 'r')) {
					cout << "YES";
				}
				else {
					cout << "NO";
				}
				/*char kolor = 'r';
				int wolne_miejsca = size * size - (red + blue);
				if (wolne_miejsca <= 2
					|| !IS_BOARD_POSSIBLE(board, size, red, blue)
					|| !IS_BOARD_CORRECT(red, blue)
					|| IS_GAME_OVER(board, 'r', size)
					|| IS_GAME_OVER(board, 'b', size))
				{
					return false;
				}

				int wymagane_wolne_miejsca;
				if ((kolor == 'r') == (red == blue))
				{
					wymagane_wolne_miejsca = 3;
				}
				else
				{
					wymagane_wolne_miejsca = 4;
				}

				if (wolne_miejsca < wymagane_wolne_miejsca) {
					return false;
				}

				char** kopia = kopiaCalejTab(board, size);
				for (int row_1 = 0; row_1 < size; row_1++) {
					for (int col_1 = 0; col_1 < size; col_1++) {
						if (kopia[row_1][col_1] == ' ') {
							kopia[row_1][col_1] = kolor;
							for (int row_2 = 0; row_2 < size; row_2++) {
								for (int col_2 = 0; col_2 < size; col_2++) {
									if (kopia[row_2][col_2] == ' ') {
										kopia[row_2][col_2] = kolor;
										if (IS_GAME_OVER(kopia, kolor, size)) {
											kopia[row_1][col_1] = ' ';
											if (!IS_GAME_OVER(kopia, kolor, size)) {
												usunTablice(kopia, size);
												return true;
											}
											kopia[row_1][col_1] = kolor;
											kopia[row_2][col_2] = ' ';
											if (!IS_GAME_OVER(kopia, kolor, size)) {
												usunTablice(kopia, size);
												return true;
											}
										}
										kopia[row_2][col_2] = ' ';
									}
								}
							}
							kopia[row_1][col_1] = ' ';
						}
					}
				}

				usunTablice(kopia, size);
				return false;*/
			}
			else if(nrPytania == 9){
				counter++;
				if (CAN_WIN_IN_2_MOVES_WITH_NAIVE_OPPONENT(board, size, red, blue, 'b')) {
					cout << "YES" << endl;
				}
				else {
					cout << "NO" << endl;
				}
				/*char kolor = 'b';
				int wolne_miejsca = size * size - (red + blue);
				if (wolne_miejsca <= 2
					|| !IS_BOARD_POSSIBLE(board, size, red, blue)
					|| !IS_BOARD_CORRECT(red, blue)
					|| IS_GAME_OVER(board, 'r', size)
					|| IS_GAME_OVER(board, 'b', size))
				{
					return false;
				}

				int wymagane_wolne_miejsca;
				if ((kolor == 'r') == (red == blue))
				{
					wymagane_wolne_miejsca = 3;
				}
				else
				{
					wymagane_wolne_miejsca = 4;
				}

				if (wolne_miejsca < wymagane_wolne_miejsca) {
					return false;
				}

				char** kopia = kopiaCalejTab(board, size);
				for (int row_1 = 0; row_1 < size; row_1++) {
					for (int col_1 = 0; col_1 < size; col_1++) {
						if (kopia[row_1][col_1] == ' ') {
							kopia[row_1][col_1] = kolor;
							for (int row_2 = 0; row_2 < size; row_2++) {
								for (int col_2 = 0; col_2 < size; col_2++) {
									if (kopia[row_2][col_2] == ' ') {
										kopia[row_2][col_2] = kolor;
										if (IS_GAME_OVER(kopia, kolor, size)) {
											kopia[row_1][col_1] = ' ';
											if (!IS_GAME_OVER(kopia, kolor, size)) {
												usunTablice(kopia, size);
												return true;
											}
											kopia[row_1][col_1] = kolor;
											kopia[row_2][col_2] = ' ';
											if (!IS_GAME_OVER(kopia, kolor, size)) {
												usunTablice(kopia, size);
												return true;
											}
										}
										kopia[row_2][col_2] = ' ';
									}
								}
							}
							kopia[row_1][col_1] = ' ';
						}
					}
				}

				usunTablice(kopia, size);
				return false;*/
			}
			else if (nrPytania == 10) {
				continue;
			}
			else if (nrPytania == 11) {
				continue;
			}
			else if (nrPytania == 12) {
				continue;
			}
			else if (nrPytania == 13) {
				continue;
			}
			cout << endl;
			
		}
		//cout << counter;
		usunTablice(board, size);	
	}

	
	return 0;

}

