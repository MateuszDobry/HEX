#pragma once

bool IS_BOARD_CORRECT(int red, int blue);