#pragma once

bool DFS(char**& board, int row, int col, char pionek, bool**& visited, int size);