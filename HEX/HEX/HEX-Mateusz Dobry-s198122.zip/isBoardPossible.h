#pragma once

bool IS_BOARD_POSSIBLE(char**& board, const int size, const int red, const int blue);