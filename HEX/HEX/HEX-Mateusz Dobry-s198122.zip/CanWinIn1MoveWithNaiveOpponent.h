#pragma once

bool CAN_WIN_IN_1_MOVE_WITH_NAIVE_OPPONENT(char**& board, int size, int red, int blue, char kolor);
