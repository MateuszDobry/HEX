#include "CanWinIn2MoveWithNaiveOpponent.h"
#include <iostream>
#include "isBoardCorrect.h"
#include "isGameOver.h"
#include "pomocniczeFunkcje.h"
#include "isBoardPossible.h"

bool CAN_WIN_IN_2_MOVES_WITH_NAIVE_OPPONENT(char**& board, int size, int red, int blue, char kolor)
{
	int ogr1 = 0, ogr2 = 0;
	switch (kolor) {
	case 'r':
		ogr1 = 3;
		ogr2 = 4;
		break;
	case 'b':
		ogr1 = 4;
		ogr2 = 3;
		break;
	}
	
	if (IS_BOARD_POSSIBLE(board, size, red, blue)) {
		if (!IS_GAME_OVER(board, 'r', size) && !IS_GAME_OVER(board,'b',size)) {
			char** kopia = kopiaCalejTab(board, size);
			int wolneMiejsca = ileSpacji(board, size);
			if (red == blue) {
				if (wolneMiejsca < ogr1) {
					usunTablice(kopia, size);
					return false;
				}
				else {
					for (int i = 0; i < size; i++) {
						for (int j = 0; j < size; j++) {
							if (kopia[i][j] == ' ') {
								kopia[i][j] = kolor;
								if (!IS_GAME_OVER(kopia, kolor, size)) {
									for (int k = 0; k < size; k++) {
										for (int l = 0; l < size; l++) {
											if (kopia[k][l] == ' ') {
												kopia[k][l] = kolor;
												if (IS_GAME_OVER(kopia, kolor, size)) {
													usunTablice(kopia, size);
													return true;
												}
												else {
													kopia[k][l] = ' ';
												}
											}
										}
									}
									
								}
								kopia[i][j] = ' ';
							}
						}
					}
				}

			}
			else {
				if (wolneMiejsca < ogr2) {
					usunTablice(kopia, size);
					return false;
				}
				else {
					for (int i = 0; i < size; i++) {
						for (int j = 0; j < size; j++) {
							if (kopia[i][j] == ' ') {
								kopia[i][j] = kolor;
								if (!IS_GAME_OVER(kopia, kolor, size)) {
									for (int k = 0; k < size; k++) {
										for (int l = 0; l < size; l++) {
											if (kopia[k][l] == ' ') {
												kopia[k][l] = kolor;
												if (IS_GAME_OVER(kopia, kolor, size)) {
													usunTablice(kopia, size);
													return true;
												}
												else {
													kopia[k][l] = ' ';
												}
											}
										}
									}
									
								}
								kopia[i][j] = ' ';
							}
						}
					}
				}
			}
			usunTablice(kopia, size);
		}
		return false;
	}
	return false;



}
