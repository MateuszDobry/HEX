#include "CanWinIn1MoveWithNaiveOpponent.h"
#include <iostream>
#include "isBoardCorrect.h"
#include "isGameOver.h"
#include "pomocniczeFunkcje.h"
#include "isBoardPossible.h"
#include "isBoardCorrect.h"

bool CAN_WIN_IN_1_MOVE_WITH_NAIVE_OPPONENT(char**& board, int size, int red, int blue, char kolor) {
	int ogr1 = 0, ogr2 = 0;
	switch (kolor) {
	case 'r':
		ogr1 = 1;
		ogr2 = 2;
		break;
	case 'b':
		ogr1 = 2;
		ogr2 = 1;
		break;
	}
		
	if (IS_BOARD_POSSIBLE(board, size, red, blue)) {
		if (IS_BOARD_CORRECT(red, blue)) {
			if (!IS_GAME_OVER(board, 'r', size) && !IS_GAME_OVER(board, 'b', size)) {
				char** kopia = kopiaCalejTab(board, size);
				int wolneMiejsca = ileSpacji(board, size); // size*size - (red+blue);
				if (red == blue) {
					if (wolneMiejsca < ogr1) {
						usunTablice(kopia, size);
						return false;
					}
					else {
						for (int i = 0; i < size; i++) {
							for (int j = 0; j < size; j++) {
								if (kopia[i][j] == ' ') {
									kopia[i][j] = kolor;
									if (IS_GAME_OVER(kopia, kolor, size)) {
										usunTablice(kopia, size);
										return true;
									}
									else {
										kopia[i][j] = ' ';
									}
								}
							}
						}
					}
				}
				else {
					if (wolneMiejsca < ogr2) {
						usunTablice(kopia, size);
						return false;
					}
					else {
						for (int i = 0; i < size; i++) {
							for (int j = 0; j < size; j++) {
								if (kopia[i][j] == ' ') {
									kopia[i][j] = kolor;
									if (IS_GAME_OVER(kopia, kolor, size)) {
										usunTablice(kopia, size);
										return true;
									}
									else {
										kopia[i][j] = ' ';
									}
								}
							}
						}
					}
				}
				usunTablice(kopia, size);
			}
			return false;
		}
		return false;
	}
	return false;
}

bool can_win_in_n_moves_inside(Board board, Player player, int moves) {
	int diff = count_of_type(board, Player::RED) - count_of_type(board, Player::BLUE);
	if (board.ok_board_response == 0) {
		if (diff < 0 || diff > 1 || is_board_inpossible(board) ||
			is_game_over(board, Player::RED) || is_game_over(board, Player::BLUE)) {
			board.ok_board_response = 2;
		}
		else
			board.ok_board_response = 1;
	}
	if (board.ok_board_response == 2)
		return false;
	std::vector<int> empty_spaces;
	for (int y = 0; y < board.size * board.size; y++) {
		if (board.array[y] == Player::EMPTY)
			empty_spaces.push_back(y);
	}
	int enemy_moves = moves;
	// red starts
	if (diff == 0 && player == Player::RED)
		enemy_moves--;
	else if (diff == 1 && player == Player::BLUE)
		enemy_moves--;
	int total_moves = empty_spaces.size() - enemy_moves;
	if (total_moves < moves)
		return false;
	for (auto i : empty_spaces) {
		board.array[i] = player;
		bool is_over = is_game_over(board, player);
		if (is_over && moves == 1)
			return true;
		else if (!is_over && moves == 2) {
			for (auto j : empty_spaces) {
				if (i == j)
					continue;
				board.array[j] = player;
				if (is_game_over(board, player))
					return true;
				board.array[j] = Player::EMPTY;
			}
		}
		board.array[i] = Player::EMPTY;
	}
	return false;
}