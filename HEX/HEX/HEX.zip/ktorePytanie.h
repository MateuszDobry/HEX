#pragma once

#include <string>

int ktorePytanie(std::string tab);
