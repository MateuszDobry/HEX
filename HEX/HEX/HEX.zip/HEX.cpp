﻿#include <iostream>
#include <string>
#include <vector>

#include "isBoardCorrect.h"
#include "isBoardPossible.h"
#include "isGameOver.h"
#include "ktorePytanie.h"
#include "pomocniczeFunkcje.h"
#include "CanWinIn1MoveWithNaiveOpponent.h"
#include "CanWinIn2MoveWithNaiveOpponent.h"

using namespace std;

int main()
{
	int counter = 0;
	char c = ' ';
	while (c = (char)getchar() != EOF) {
		
		int red, blue;
		red = blue = 0;
		int size = 0;

		while (c != '-') {
			c = (char)getchar();
			size++;
		}
		counter++;
		size /= 3;
		size++;

		while (getchar() != '\n');  // ZACZYNA WCZYTYWAC OD 2 ' - '
		
		char** board = new char* [size];
		for (int i = 0; i < size; i++) {
			board[i] = new char[size];
		}
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				board[i][j] = '0';
			}
		}
		for (int i = 0; i < 2 * size - 1; i++) {
			counter++;
			c = '0';
			int j = 0;
			while (c != '\n') {
				
				c = (char)getchar();

				if (c == '<') {
					c = (char)getchar();
					if (c == ' ') {
						c = (char)getchar();
						if (i < size) {
							board[j][i - j] = c;
						}
						else {
							board[i - size + 1 + j][size - 1 - j] = c;
						}

						if (c == 'r') {
							red++;
						}
						if (c == 'b') {
							blue++;
						}
					}
					j++;
				}
			}
		}
		transpose(board, size);
		while (getchar() != '\n'); /// TUTAJ KONCZY WCZYTYWAC PLANSZE
		counter++;
		string pytanie = "";
	pkt:

		while (pytanie[0] != '\n') {
			getline(cin, pytanie);
			counter++;
			if (pytanie.empty()) {
				pytanie.push_back('\n');
			}
			if (pytanie[0] == '\n') {
				goto pkt;
			}
			int nrPytania = ktorePytanie(pytanie);
			if (nrPytania == 1) {
				cout << size << endl;
			}
			else if (nrPytania == 2) {
				cout << red + blue << endl;
			}
			else if (nrPytania == 3) {
				if (IS_BOARD_CORRECT(red, blue)) {
					cout << "YES" << endl;
				}
				else
					cout << "NO" << endl;
			}
			else if (nrPytania == 4) {
				if (IS_BOARD_CORRECT(red, blue)) {


					if (IS_GAME_OVER(board, 'r', size)) {
						cout << "YES RED" << endl;
					}
					else if (IS_GAME_OVER(board, 'b', size)) {
						cout << "YES BLUE" << endl;
					}
					else {
						cout << "NO" << endl;
					}
				}
				else {
					cout << "NO" << endl;
				}

			}
			else if (nrPytania == 5) {
				if (IS_BOARD_POSSIBLE(board, size, red, blue)) {
					cout << "YES" << endl;
				}
				else {
					cout << "NO" << endl;
				}
			}
			else if (nrPytania == 6) {
				if (CAN_WIN_IN_1_MOVE_WITH_NAIVE_OPPONENT(board,size, red, blue,'r')) {
					cout << "YES";
				}
				else {
					cout << "NO";
				}
			}
			else if (nrPytania == 7) {
				if (CAN_WIN_IN_1_MOVE_WITH_NAIVE_OPPONENT(board, size, red, blue, 'b')) {
					cout << "YES";
				}
				else {
					cout << "NO";
				}
			}
			else if (nrPytania == 8) {
				if (CAN_WIN_IN_2_MOVES_WITH_NAIVE_OPPONENT(board, size, red, blue, 'r')) {
					cout << "YES";
				}
				else {
					cout << "NO";
				}
			}
			else if(nrPytania == 9){
				if (CAN_WIN_IN_2_MOVES_WITH_NAIVE_OPPONENT(board, size, red, blue, 'b')) {
					cout << "YES" << endl;
				}
				else {
					cout << "NO" << endl;
				}
			}
			cout << endl;
			
		}
		//cout << counter;
		usunTablice(board, size);	
	}

	
	return 0;

}

