#pragma once

bool IS_GAME_OVER(char**& board, char player, int size);